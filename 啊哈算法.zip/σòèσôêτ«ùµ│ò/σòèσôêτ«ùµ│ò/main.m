//
//  main.m
//  啊哈算法
//
//  Created by can can on 2021/6/9.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        // insert code here...
        NSLog(@"Hello, World!");
        //输入五个0——10的数
//        int a[11],i,j,t;
//        for (i = 0; i<=10; i++)
//            a[i] = 0;
//
//        for (i=1; i<=5; i++) {
//            printf("请输入：");
//            scanf("%d",&t);
//            a[t]++;
//        }
//        for (i = 10; i>=0; i--)
//            for (j=1; j<=a[i]; j++)
//                printf("%d",i);
            
//        getchar();
        
//        int book[1001],i,j,t,n;
//        for (i=0; i<=1000; i++) {
//            book[i]=0;
//        }
//        printf("请输入：");
//        scanf("%d",&n);
//
//        for (i=1; i<=n; i++) {
//            scanf("%d",&t);
//            book[t]++;
//        }
//        for (i = 1000; i>=0; i--) {
//            for (j=1; j<=book[i]; j++) {
//                printf("%d",i);
//            }
//        }
        
        //打印99乘法表
//        int i,j,sum;
//        for (i=1; i<10; i++) {
//            for (j=9; j>=i; j-- ) {
//                sum = i*j;
////                while (j<i) {--
//////                    printf("\t");
////                    j++;
////                }
//                printf("%d * %d = %d\t",i,j,sum);
//            }
//            printf("\n");
//        }
        
        getchar();
        
    }
    return 0;
}
